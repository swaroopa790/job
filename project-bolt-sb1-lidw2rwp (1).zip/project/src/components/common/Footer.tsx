import React from 'react';
import { BarChart, Mail, Phone, MapPin, Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <BarChart className="h-7 w-7 text-blue-500" />
              <span className="ml-2 text-xl font-bold text-white">JobSensei</span>
            </div>
            <p className="mb-4 text-gray-400">
              Empowering tier-2/3 college students with personalized career navigation tools and opportunities.
            </p>
            <div className="space-y-2">
              <div className="flex items-start">
                <Mail className="h-5 w-5 mr-2 text-gray-400 mt-0.5" />
                <span>contact@jobsensei.com</span>
              </div>
              <div className="flex items-start">
                <Phone className="h-5 w-5 mr-2 text-gray-400 mt-0.5" />
                <span>+91 98765 43210</span>
              </div>
              <div className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 text-gray-400 mt-0.5" />
                <span>Koramangala, Bangalore, India</span>
              </div>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="/about" className="text-gray-400 hover:text-blue-400 transition duration-150">About Us</a>
              </li>
              <li>
                <a href="/jobs" className="text-gray-400 hover:text-blue-400 transition duration-150">Find Jobs</a>
              </li>
              <li>
                <a href="/resources" className="text-gray-400 hover:text-blue-400 transition duration-150">Resources</a>
              </li>
              <li>
                <a href="/partners" className="text-gray-400 hover:text-blue-400 transition duration-150">Partner With Us</a>
              </li>
              <li>
                <a href="/blog" className="text-gray-400 hover:text-blue-400 transition duration-150">Blog</a>
              </li>
              <li>
                <a href="/contact" className="text-gray-400 hover:text-blue-400 transition duration-150">Contact</a>
              </li>
            </ul>
          </div>
          
          {/* Resources */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <a href="/resume-templates" className="text-gray-400 hover:text-blue-400 transition duration-150">Resume Templates</a>
              </li>
              <li>
                <a href="/interview-prep" className="text-gray-400 hover:text-blue-400 transition duration-150">Interview Preparation</a>
              </li>
              <li>
                <a href="/skill-development" className="text-gray-400 hover:text-blue-400 transition duration-150">Skill Development</a>
              </li>
              <li>
                <a href="/career-guides" className="text-gray-400 hover:text-blue-400 transition duration-150">Career Guides</a>
              </li>
              <li>
                <a href="/webinars" className="text-gray-400 hover:text-blue-400 transition duration-150">Webinars & Events</a>
              </li>
            </ul>
          </div>
          
          {/* Newsletter */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Stay Updated</h3>
            <p className="text-gray-400 mb-4">Subscribe to our newsletter for career tips and job opportunities.</p>
            <form className="mb-4">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email address"
                  className="px-4 py-2 w-full rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-4 py-2 rounded-r-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  Subscribe
                </button>
              </div>
            </form>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-blue-400 transition duration-150">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition duration-150">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition duration-150">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition duration-150">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400">© 2025 JobSensei. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a href="/privacy" className="text-gray-400 hover:text-blue-400 transition duration-150 text-sm">
              Privacy Policy
            </a>
            <a href="/terms" className="text-gray-400 hover:text-blue-400 transition duration-150 text-sm">
              Terms of Service
            </a>
            <a href="/sitemap" className="text-gray-400 hover:text-blue-400 transition duration-150 text-sm">
              Sitemap
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;