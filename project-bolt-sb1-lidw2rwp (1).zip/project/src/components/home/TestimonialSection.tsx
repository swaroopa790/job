import React from 'react';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    id: '1',
    content: 'JobSensei helped me land my first software developer role despite coming from a tier-3 college. Their resume builder and interview prep were game-changers!',
    author: 'Aditya Sharma',
    position: 'Software Developer at TechStart',
    college: 'Regional Engineering College, Bhopal',
    image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '2',
    content: 'I was struggling to get interviews until I used JobSensei. Their skill assessment helped me identify gaps, and the personalized job matches actually led to opportunities.',
    author: 'Priya Desai',
    position: 'Data Analyst at DataViz',
    college: 'Government Engineering College, Pune',
    image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  },
  {
    id: '3',
    content: 'Coming from a tier-3 college, I faced many rejections. JobSensei\'s career pathway visualization helped me plan my learning journey, and now I work at a top tech company!',
    author: 'Rajesh Kumar',
    position: 'Product Manager at GrowthFirst',
    college: 'State Technical University, Lucknow',
    image: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
  }
];

const TestimonialSection: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Success Stories
          </h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            Hear from students who transformed their careers with JobSensei.
          </p>
        </div>
        
        <div className="grid gap-8 md:grid-cols-3">
          {testimonials.map((testimonial) => (
            <div 
              key={testimonial.id} 
              className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 relative flex flex-col"
            >
              <Quote className="h-8 w-8 text-blue-100 absolute top-6 right-6" />
              
              <div className="mb-6 flex-grow">
                <p className="text-gray-700 italic">{testimonial.content}</p>
              </div>
              
              <div className="flex items-center">
                <div className="mr-4">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.author} 
                    className="h-12 w-12 rounded-full object-cover border-2 border-blue-100"
                  />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">{testimonial.author}</h4>
                  <p className="text-sm text-gray-600">{testimonial.position}</p>
                  <p className="text-xs text-gray-500">{testimonial.college}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialSection;