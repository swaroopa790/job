import React from 'react';
import { ExternalLink, Clock, MapPin, Briefcase } from 'lucide-react';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Card, CardContent, CardFooter } from '../ui/Card';
import { mockJobs } from '../../data/mockData';

const JobListingSection: React.FC = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Opportunities For You
          </h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            Discover job opportunities that match your skills and aspirations.
          </p>
        </div>
        
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {mockJobs.slice(0, 3).map((job) => (
            <Card key={job.id} hoverable className="h-full flex flex-col">
              <CardContent className="pb-0 flex-grow">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-xl text-gray-900">{job.title}</h3>
                    <p className="text-gray-600">{job.company}</p>
                  </div>
                  {job.companyLogo && (
                    <div className="h-12 w-12 rounded overflow-hidden bg-white p-1 border border-gray-200 flex items-center justify-center">
                      <img 
                        src={job.companyLogo} 
                        alt={`${job.company} logo`} 
                        className="h-9 w-9 object-contain"
                      />
                    </div>
                  )}
                </div>
                
                <div className="mb-4 flex flex-wrap gap-2">
                  <Badge variant={job.matchScore && job.matchScore > 80 ? 'success' : 'info'}>
                    {job.matchScore}% Match
                  </Badge>
                  <Badge variant="secondary">{job.type}</Badge>
                </div>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm text-gray-500">
                    <MapPin className="h-4 w-4 mr-1" />
                    {job.location}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Briefcase className="h-4 w-4 mr-1" />
                    {job.experience}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    Posted on {new Date(job.postedDate).toLocaleDateString()}
                  </div>
                </div>
                
                <div className="mt-2">
                  <p className="text-gray-700 line-clamp-3">{job.description}</p>
                </div>
                
                <div className="mt-4 flex flex-wrap gap-2">
                  {job.requirements.slice(0, 3).map((requirement, index) => (
                    <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                      {requirement}
                    </span>
                  ))}
                  {job.requirements.length > 3 && (
                    <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                      +{job.requirements.length - 3} more
                    </span>
                  )}
                </div>
              </CardContent>
              
              <CardFooter className="border-t border-gray-100 flex justify-between">
                <Button variant="outline" size="sm">
                  Save
                </Button>
                <Button 
                  variant="primary" 
                  size="sm" 
                  className="flex items-center"
                >
                  View Job
                  <ExternalLink className="ml-1 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <Button variant="secondary" size="lg">
            View All Job Opportunities
          </Button>
        </div>
      </div>
    </section>
  );
};

export default JobListingSection;