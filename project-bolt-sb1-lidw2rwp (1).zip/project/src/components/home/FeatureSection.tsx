import React from 'react';
import { Target, FileText, Users, BookOpen, BarChart2, Calendar } from 'lucide-react';

const features = [
  {
    icon: <Target className="h-8 w-8 text-blue-600" />,
    title: 'Personalized Job Matching',
    description: 'Discover opportunities aligned with your skills, interests, and college background.'
  },
  {
    icon: <FileText className="h-8 w-8 text-yellow-600" />,
    title: 'Resume Builder',
    description: 'Create ATS-friendly resumes with templates designed for tier-2/3 college graduates.'
  },
  {
    icon: <BookOpen className="h-8 w-8 text-purple-600" />,
    title: 'Skill Development',
    description: 'Identify skill gaps and access curated resources to enhance your employability.'
  },
  {
    icon: <Users className="h-8 w-8 text-green-600" />,
    title: 'Alumni Network',
    description: 'Connect with successful graduates from similar backgrounds for mentorship and guidance.'
  },
  {
    icon: <BarChart2 className="h-8 w-8 text-indigo-600" />,
    title: 'Career Pathways',
    description: 'Visualize potential career trajectories based on your education and skills.'
  },
  {
    icon: <Calendar className="h-8 w-8 text-red-600" />,
    title: 'Interview Preparation',
    description: 'Practice with industry-specific questions and get feedback on your responses.'
  }
];

const FeatureSection: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Tools Designed for Your Success
          </h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            JobSensei provides specialized resources to help students from tier-2/3 colleges
            navigate the job market effectively.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-white rounded-lg p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeatureSection;