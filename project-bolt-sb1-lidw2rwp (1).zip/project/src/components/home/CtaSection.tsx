import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from '../ui/Button';

const CtaSection: React.FC = () => {
  return (
    <section className="py-16 bg-blue-600">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-white sm:text-4xl mb-4">
            Ready to Take the Next Step in Your Career?
          </h2>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Join thousands of students who are building successful careers with JobSensei.
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
          <Button
            variant="primary"
            size="lg"
            className="bg-white text-blue-600 hover:bg-blue-50 px-8"
          >
            Create Free Account
          </Button>
          
          <Button
            variant="outline"
            size="lg"
            className="border-white text-white hover:bg-white/10 px-8"
          >
            <span>Explore Features</span>
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
        
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <p className="text-3xl font-bold text-white mb-1">10,000+</p>
            <p className="text-blue-200">Students</p>
          </div>
          <div>
            <p className="text-3xl font-bold text-white mb-1">5,000+</p>
            <p className="text-blue-200">Job Placements</p>
          </div>
          <div>
            <p className="text-3xl font-bold text-white mb-1">200+</p>
            <p className="text-blue-200">Partner Colleges</p>
          </div>
          <div>
            <p className="text-3xl font-bold text-white mb-1">150+</p>
            <p className="text-blue-200">Hiring Companies</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;