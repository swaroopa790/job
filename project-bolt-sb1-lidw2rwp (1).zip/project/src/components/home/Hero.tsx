import React from 'react';
import { SearchIcon, TrendingUp, BookOpen, FileText } from 'lucide-react';
import { Button } from '../ui/Button';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-gradient-to-r from-blue-600 to-purple-600 overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 bg-yellow-400 w-64 h-64 rounded-full mix-blend-multiply filter blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 bg-purple-400 w-80 h-80 rounded-full mix-blend-multiply filter blur-3xl"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32 relative z-10">
        <div className="md:flex md:items-center md:justify-between">
          <div className="md:w-1/2 mb-12 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold text-white leading-tight mb-6 animate-fade-in-up">
              Your Career Navigator for Success
            </h1>
            <p className="text-xl text-blue-100 mb-8 max-w-lg animate-fade-in-up animation-delay-150">
              Personalized career guidance and job opportunities tailored for tier-2/3 college students. Bridge the gap between education and employment.
            </p>
            <div className="flex flex-wrap gap-4 animate-fade-in-up animation-delay-300">
              <Button
                variant="primary"
                size="lg"
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                Get Started
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white/10"
              >
                Explore Jobs
              </Button>
            </div>
            
            <div className="mt-12 flex items-center text-blue-100 animate-fade-in-up animation-delay-450">
              <span className="mr-2 font-semibold">Trusted by 10,000+ students from 200+ colleges</span>
            </div>
          </div>
          
          <div className="md:w-1/2 mx-auto md:mx-0 max-w-md">
            <div className="bg-white bg-opacity-95 backdrop-filter backdrop-blur-sm rounded-xl shadow-xl p-6 animate-fade-in-up animation-delay-300">
              <div className="mb-4">
                <h3 className="text-lg font-medium text-gray-900 mb-2">Quick Search</h3>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search for jobs, skills, or companies"
                    className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <SearchIcon className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 gap-3">
                <button className="flex items-center p-3 rounded-lg text-left hover:bg-gray-50 transition duration-150">
                  <div className="bg-blue-100 p-2 rounded-md">
                    <TrendingUp className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900">Explore trending career paths</p>
                    <p className="text-xs text-gray-500">Discover the most in-demand skills and jobs</p>
                  </div>
                </button>
                
                <button className="flex items-center p-3 rounded-lg text-left hover:bg-gray-50 transition duration-150">
                  <div className="bg-purple-100 p-2 rounded-md">
                    <BookOpen className="h-5 w-5 text-purple-600" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900">Skill gap assessment</p>
                    <p className="text-xs text-gray-500">Find what you need to learn next</p>
                  </div>
                </button>
                
                <button className="flex items-center p-3 rounded-lg text-left hover:bg-gray-50 transition duration-150">
                  <div className="bg-yellow-100 p-2 rounded-md">
                    <FileText className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900">Resume builder</p>
                    <p className="text-xs text-gray-500">Create an ATS-friendly resume</p>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;