import { Job, Skill, Resource, Application } from '../types';

export const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Frontend Developer',
    company: 'TechStart Solutions',
    location: 'Bangalore',
    type: 'Full-time',
    experience: '0-2 years',
    salary: '₹4-6 LPA',
    description: 'Looking for a passionate frontend developer with React skills to join our growing team.',
    requirements: ['React', 'JavaScript', 'HTML/CSS', 'Responsive Design'],
    postedDate: '2025-03-10',
    applicationDeadline: '2025-04-10',
    companyLogo: 'https://images.pexels.com/photos/2977547/pexels-photo-2977547.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    matchScore: 87
  },
  {
    id: '2',
    title: 'Data Analyst Intern',
    company: 'DataViz Analytics',
    location: 'Remote',
    type: 'Internship',
    experience: '0-1 years',
    salary: '₹15-25K monthly',
    description: 'Join our data team to analyze business metrics and create visualizations.',
    requirements: ['SQL', 'Excel', 'Basic Statistics', 'Data Visualization'],
    postedDate: '2025-03-15',
    applicationDeadline: '2025-04-15',
    companyLogo: 'https://images.pexels.com/photos/590041/pexels-photo-590041.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    matchScore: 92
  },
  {
    id: '3',
    title: 'Junior Software Engineer',
    company: 'Innovate Systems',
    location: 'Pune',
    type: 'Full-time',
    experience: '0-2 years',
    salary: '₹3.5-5 LPA',
    description: 'Develop and maintain backend services and APIs for our enterprise clients.',
    requirements: ['Java', 'Spring Boot', 'REST APIs', 'SQL'],
    postedDate: '2025-03-18',
    applicationDeadline: '2025-04-20',
    companyLogo: 'https://images.pexels.com/photos/430205/pexels-photo-430205.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    matchScore: 75
  },
  {
    id: '4',
    title: 'Product Manager Trainee',
    company: 'GrowthFirst',
    location: 'Hyderabad',
    type: 'Full-time',
    experience: '0-1 years',
    salary: '₹5-7 LPA',
    description: 'Exciting opportunity for fresh graduates to learn product management in a fast-paced startup.',
    requirements: ['Analytical Skills', 'Communication', 'Basic Technical Knowledge', 'Problem Solving'],
    postedDate: '2025-03-20',
    applicationDeadline: '2025-04-25',
    companyLogo: 'https://images.pexels.com/photos/935979/pexels-photo-935979.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    matchScore: 82
  },
  {
    id: '5',
    title: 'Digital Marketing Associate',
    company: 'BrandBoost Media',
    location: 'Mumbai',
    type: 'Part-time',
    experience: '0-2 years',
    salary: '₹20-30K monthly',
    description: 'Help manage social media campaigns and content marketing initiatives.',
    requirements: ['Social Media Management', 'Content Creation', 'Basic SEO', 'Analytics'],
    postedDate: '2025-03-22',
    applicationDeadline: '2025-04-22',
    companyLogo: 'https://images.pexels.com/photos/1447254/pexels-photo-1447254.png?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    matchScore: 68
  }
];

export const mockSkills: Skill[] = [
  { id: '1', name: 'JavaScript', category: 'Technical', level: 'Intermediate' },
  { id: '2', name: 'React', category: 'Technical', level: 'Beginner' },
  { id: '3', name: 'SQL', category: 'Technical', level: 'Beginner' },
  { id: '4', name: 'Communication', category: 'Soft', level: 'Intermediate' },
  { id: '5', name: 'Problem Solving', category: 'Soft', level: 'Intermediate' },
  { id: '6', name: 'Data Analysis', category: 'Domain', level: 'Beginner' }
];

export const mockResources: Resource[] = [
  {
    id: '1',
    title: 'How to Create a Standout Resume for Tech Jobs',
    type: 'Article',
    link: 'https://example.com/resume-guide',
    description: 'A comprehensive guide to creating a resume that gets noticed by tech recruiters.',
    tags: ['Resume', 'Tech Jobs', 'Career Advice']
  },
  {
    id: '2',
    title: 'SQL Crash Course for Beginners',
    type: 'Video',
    link: 'https://example.com/sql-course',
    description: 'Learn SQL basics in under 2 hours with practical examples.',
    tags: ['SQL', 'Database', 'Technical Skills']
  },
  {
    id: '3',
    title: 'Mock Technical Interview Practice',
    type: 'Practice',
    link: 'https://example.com/mock-interview',
    description: 'Practice common interview questions for entry-level technical roles.',
    tags: ['Interview Prep', 'Technical Interview', 'Practice']
  },
  {
    id: '4',
    title: 'Introduction to Data Structures and Algorithms',
    type: 'Course',
    link: 'https://example.com/dsa-course',
    description: 'Master the fundamentals of DSA to ace technical interviews.',
    tags: ['DSA', 'Programming', 'Interview Prep']
  }
];

export const mockApplications: Application[] = [
  {
    id: '1',
    jobId: '1',
    status: 'Applied',
    appliedDate: '2025-03-20',
    notes: 'Applied through company website'
  },
  {
    id: '2',
    jobId: '2',
    status: 'Screening',
    appliedDate: '2025-03-15',
    notes: 'HR contacted for initial screening call scheduled for next week'
  },
  {
    id: '3',
    jobId: '3',
    status: 'Interview',
    appliedDate: '2025-03-10',
    notes: 'Technical interview scheduled for March 30th'
  }
];