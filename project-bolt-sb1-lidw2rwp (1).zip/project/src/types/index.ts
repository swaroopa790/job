export interface User {
  id: string;
  name: string;
  email: string;
  college: string;
  graduation: string;
  skills: string[];
  resume?: string;
}

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  type: 'Full-time' | 'Part-time' | 'Internship' | 'Remote';
  experience: string;
  salary: string;
  description: string;
  requirements: string[];
  postedDate: string;
  applicationDeadline: string;
  companyLogo?: string;
  matchScore?: number;
}

export interface Application {
  id: string;
  jobId: string;
  status: 'Applied' | 'Screening' | 'Interview' | 'Offered' | 'Rejected';
  appliedDate: string;
  notes?: string;
}

export interface Skill {
  id: string;
  name: string;
  category: 'Technical' | 'Soft' | 'Domain';
  level: 'Beginner' | 'Intermediate' | 'Advanced';
}

export interface Resource {
  id: string;
  title: string;
  type: 'Article' | 'Video' | 'Course' | 'Practice' | 'Template';
  link: string;
  description: string;
  tags: string[];
}